package com.alumno.decasport;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    // Posición de "Productos y stock" en los arrays: es la única opción que ve el cliente
    private static final int POSICION_PRODUCTOS = 1;

    // Datos de las 6 opciones del menú (texto, icono y color del recuadro)
    private final int[] titulos = {
            R.string.menu_clientes,
            R.string.menu_productos,
            R.string.menu_ventas,
            R.string.menu_albaranes,
            R.string.menu_facturas,
            R.string.menu_almacenes
    };

    private final int[] iconos = {
            R.drawable.ic_clientes,
            R.drawable.ic_productos,
            R.drawable.ic_ventas,
            R.drawable.ic_albaranes,
            R.drawable.ic_facturas,
            R.drawable.ic_almacenes
    };

    private final int[] colores = {
            R.color.icono_azul,
            R.color.icono_verde,
            R.color.icono_naranja,
            R.color.icono_morado,
            R.color.icono_rojo,
            R.color.icono_turquesa
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Rol recibido del login. Si no llega ninguno, se trata como cliente (el más restringido)
        String rol = getIntent().getStringExtra(LoginActivity.EXTRA_ROL);
        boolean esEncargado = LoginActivity.ROL_ENCARGADO.equals(rol);

        LinearLayout contenedor = findViewById(R.id.contenedorOpciones);
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 0; i < titulos.length; i++) {
            // El cliente solo ve "Productos y stock"; el encargado ve todo
            if (!esEncargado && i != POSICION_PRODUCTOS) {
                continue;
            }

            View fila = inflater.inflate(R.layout.item_menu, contenedor, false);

            ImageView icono = fila.findViewById(R.id.ivIcono);
            TextView texto = fila.findViewById(R.id.tvTitulo);

            icono.setImageResource(iconos[i]);
            texto.setText(titulos[i]);

            // Color de fondo del recuadro del icono
            GradientDrawable fondo = (GradientDrawable) getDrawable(R.drawable.fondo_icono).mutate();
            fondo.setColor(getColor(colores[i]));
            icono.setBackground(fondo);

            final String nombre = getString(titulos[i]);
            fila.setOnClickListener(v ->
                    Toast.makeText(this, nombre, Toast.LENGTH_SHORT).show());

            contenedor.addView(fila);
        }

        // Botón de las tres rayas: menú desplegable con "Cerrar sesión"
        ImageView ivMenu = findViewById(R.id.ivMenu);
        ivMenu.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, v);
            popup.getMenu().add(R.string.cerrar_sesion);
            popup.setOnMenuItemClickListener(item -> {
                Intent intent = new Intent(this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
                return true;
            });
            popup.show();
        });
    }
}
