package com.alumno.decasport;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Clave y valores del rol que se envía al menú
    public static final String EXTRA_ROL = "rol";
    public static final String ROL_ENCARGADO = "encargado";
    public static final String ROL_CLIENTE = "cliente";

    // Usuarios de prueba (cámbialos aquí cuando quieras)
    private static final String USUARIO_ENCARGADO = "encargado";
    private static final String CONTRASENA_ENCARGADO = "encargado123";
    private static final String USUARIO_CLIENTE = "cliente";
    private static final String CONTRASENA_CLIENTE = "cliente123";

    private EditText etUsuario;
    private EditText etContrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsuario = findViewById(R.id.etUsuario);
        etContrasena = findViewById(R.id.etContrasena);
        Button btnIniciarSesion = findViewById(R.id.btnIniciarSesion);
        TextView tvCrearCuenta = findViewById(R.id.tvCrearCuenta);

        btnIniciarSesion.setOnClickListener(v -> iniciarSesion());

        tvCrearCuenta.setOnClickListener(v ->
                Toast.makeText(this, R.string.crear_cuenta_proximamente, Toast.LENGTH_SHORT).show());
    }

    private void iniciarSesion() {
        String usuario = etUsuario.getText().toString().trim();
        String contrasena = etContrasena.getText().toString().trim();

        if (usuario.isEmpty()) {
            etUsuario.setError(getString(R.string.error_usuario));
            etUsuario.requestFocus();
            return;
        }
        if (contrasena.isEmpty()) {
            etContrasena.setError(getString(R.string.error_contrasena));
            etContrasena.requestFocus();
            return;
        }

        // Comprobamos qué rol corresponde a las credenciales
        String rol = null;
        if (usuario.equals(USUARIO_ENCARGADO) && contrasena.equals(CONTRASENA_ENCARGADO)) {
            rol = ROL_ENCARGADO;
        } else if (usuario.equals(USUARIO_CLIENTE) && contrasena.equals(CONTRASENA_CLIENTE)) {
            rol = ROL_CLIENTE;
        }

        if (rol == null) {
            Toast.makeText(this, R.string.error_credenciales, Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, MenuActivity.class);
        intent.putExtra(EXTRA_ROL, rol);
        startActivity(intent);
        finish();
    }
}
