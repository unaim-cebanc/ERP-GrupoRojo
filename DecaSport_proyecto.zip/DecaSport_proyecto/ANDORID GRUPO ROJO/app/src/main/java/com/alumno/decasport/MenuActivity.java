package com.alumno.decasport;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Recogemos el nombre y el rol que nos manda el login
        Bundle extras = getIntent().getExtras();
        String usuario = extras.getString("usuario");
        String rol = extras.getString("rol");

        // Ponemos el nombre del usuario en la barra de arriba
        TextView titulo = (TextView) findViewById(R.id.titulo);
        titulo.setText(getString(R.string.hola) + " " + usuario);

        // El cliente solo ve "Productos y stock", así que ocultamos el resto
        if (rol.equals("cliente")) {
            findViewById(R.id.clientes).setVisibility(View.GONE);
            findViewById(R.id.ventas).setVisibility(View.GONE);
            findViewById(R.id.albaranes).setVisibility(View.GONE);
            findViewById(R.id.facturas).setVisibility(View.GONE);
            findViewById(R.id.almacenes).setVisibility(View.GONE);
        }
    }

    // Todos los botones del menú llaman a este método (android:onClick en el layout)
    public void abrirComingSoon(View view) {
        Button boton = (Button) view;
        Intent i = new Intent(this, ComingSoonActivity.class);
        i.putExtra("titulo", boton.getText().toString());
        // El tag del botón (android:tag en el layout) dice qué sección es
        i.putExtra("seccion", (String) boton.getTag());
        startActivity(i);
    }

    // Abre la ventana "Acerca de"
    public void lanzarAcercaDe(View view) {
        Intent i = new Intent(this, AcercaDeActivity.class);
        startActivity(i);
    }

    // Vuelve a la pantalla de login
    public void cerrarSesion(View view) {
        Intent i = new Intent(this, LoginActivity.class);
        startActivity(i);
        finish();
    }
}
