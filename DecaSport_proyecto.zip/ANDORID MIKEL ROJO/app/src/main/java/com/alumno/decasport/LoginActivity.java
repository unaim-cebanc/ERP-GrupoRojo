package com.alumno.decasport;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText textUsuario;
    private EditText textContrasena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        textUsuario = (EditText) findViewById(R.id.usuario);
        textContrasena = (EditText) findViewById(R.id.contrasena);
    }

    // Se ejecuta al pulsar "Iniciar sesión" (android:onClick en el layout)
    public void iniciarSesion(View view) {
        String usuario = textUsuario.getText().toString();
        String contrasena = textContrasena.getText().toString();

        if (usuario.equals("encargado") && contrasena.equals("encargado123")) {
            lanzarMenu("encargado");
        } else if (usuario.equals("cliente") && contrasena.equals("cliente123")) {
            lanzarMenu("cliente");
        } else {
            Toast.makeText(this, R.string.error_credenciales, Toast.LENGTH_SHORT).show();
        }
    }

    // Abre el menú y le pasa el rol del usuario
    private void lanzarMenu(String rol) {
        Intent i = new Intent(this, MenuActivity.class);
        i.putExtra("rol", rol);
        startActivity(i);
        finish();
    }

    // Se ejecuta al pulsar "Crear cuenta"
    public void crearCuenta(View view) {
        Toast.makeText(this, R.string.crear_cuenta_proximamente, Toast.LENGTH_SHORT).show();
    }
}
