package com.alumno.decasport;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

// Pantalla "Acerca de" (como en el ejercicio de crear nuevas actividades)
public class AcercaDeActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acercade);
    }

    // Botón "Volver": cerramos esta pantalla y volvemos al menú
    public void volver(View view) {
        finish();
    }
}
