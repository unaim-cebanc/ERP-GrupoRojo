package com.alumno.decasport;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ComingSoonActivity extends AppCompatActivity {

    private TextView aviso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_soon);

        // Recogemos el nombre del botón pulsado y su sección
        String seccion = "";
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            TextView titulo = (TextView) findViewById(R.id.titulo);
            titulo.setText(extras.getString("titulo"));
            seccion = extras.getString("seccion");
        }

        // ListView: lista con lo que se podrá hacer en esta sección (ejercicio List_View)
        String[] opciones = getResources().getStringArray(elegirLista(seccion));
        ArrayAdapter<String> adaptadorLista = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, opciones);
        ListView lista = (ListView) findViewById(R.id.lista);
        lista.setAdapter(adaptadorLista);

        // Spinner: elegir cómo quieres que te avisemos (ejercicio Spinner)
        ArrayAdapter<CharSequence> adaptadorSpinner = ArrayAdapter.createFromResource(
                this, R.array.formas_aviso, android.R.layout.simple_spinner_item);
        adaptadorSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setAdapter(adaptadorSpinner);

        aviso = (TextView) findViewById(R.id.aviso);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                aviso.setText(getString(R.string.te_avisaremos) + " " + parent.getItemAtPosition(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                aviso.setText("");
            }
        });
    }

    // Devuelve la lista (string-array de strings.xml) que corresponde a cada sección
    private int elegirLista(String seccion) {
        if (seccion.equals("clientes")) {
            return R.array.lista_clientes;
        } else if (seccion.equals("productos")) {
            return R.array.lista_productos;
        } else if (seccion.equals("ventas")) {
            return R.array.lista_ventas;
        } else if (seccion.equals("albaranes")) {
            return R.array.lista_albaranes;
        } else if (seccion.equals("facturas")) {
            return R.array.lista_facturas;
        } else {
            return R.array.lista_almacenes;
        }
    }

    // Botón "Volver": cerramos esta pantalla y volvemos al menú
    public void volver(View view) {
        finish();
    }
}
